#include <chrono>
#include "Yolo.h"
#include "load_images.h"

#define SINGLE_THREAD
using namespace std;

static const std::string inputVideoFile = "./demo1-720p.mp4";
static const std::string inputModelFile = "./tiny-yolo-kitti.prototxt";
static const std::string inputWeightFile = "./tiny-yolo-kitti-cpc-benchmark_final.caffemodel";
static cv::VideoCapture g_vc(inputVideoFile);
static const std::string img_dir = "/home/cuda/zhihengw/benchmark/training/image_2/";
static const std::string result_dir = "/home/cuda/zhihengw/benchmark/yolo/image_2_train/";


int main(int argc,char **argv){
	//Yolo yolo(inputModelFile, inputWeightFile, PlatformType::FPGA, 0.2, 0.5, 0.5, 3, 2, 7, 3, true);
	Yolo yolo(inputModelFile, inputWeightFile, PlatformType::GPU, 0.001, 0.5, 1.5, 3, 5, 23, 7, 3, false); // n_box 5, n_gride

	std::vector<std::string> files_list;
	GetAllFiles(img_dir, files_list);
	std::vector<ARectangle> boxes;

	cv::Mat img;
	cv::namedWindow("yolo",cv::WINDOW_AUTOSIZE);

	for(int i = 0; i < 8000; ++i){
		//g_vc >> img;

		if((int)files_list.size() < i+1){
			cout << "empty image id for loading... finish." << endl;
			break;
		}
		std::vector<std::string> splited_strs;
		SplitString(files_list[i], splited_strs, ".");
		std::string image_id = splited_strs[0];
		img = cv::imread(img_dir+files_list[i]);

		yolo.predict(img, boxes);
		cout << "boxes number: " << boxes.size() << endl;
		WriteDetectionToFile(result_dir+image_id+".txt", boxes);

		//imshow("yolo", img);
		cv::waitKey(1);
	}

	cv::destroyAllWindows();
	return 0; 
}
