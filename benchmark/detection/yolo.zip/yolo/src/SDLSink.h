#ifndef SDLSINK_H
#define SDLSINK_H

#include "SDL2/SDL.h"
#include "GlobalSetting.h"

enum DRAW_OBJECT{
    draw_pixel,
    draw_line,
    draw_circle,
    draw_rect
};

class SDLSink {
public:
	SDLSink();
	SDLSink(int x, int y, unsigned int w, unsigned int h);
	virtual ~SDLSink();	
	bool openSink();
	void closeSink();
	void render();
	void render(void* pixels);
	void updateVideoBuffer(void* buffer);
	bool lockData();
	bool unlockData();
	void* getData();
    bool setTexture(unsigned int w, unsigned int h, ImgFmt fmt);
	bool drawObject(const DRAW_OBJECT object, void* data);

private:
	void* pixels = NULL;
	SDL_Window *surface = NULL;
	SDL_Renderer *renderer = NULL;
	SDL_Texture* texture = NULL;
	SDL_Rect rect;
	unsigned int width;
	unsigned int height;
    unsigned int texture_w;
    unsigned int texture_h;
    ImgFmt texture_f;
	int px;
	int py;
	void drawLine(int x, int y, int len);
	void drawRect(ARectangle* r);
    int getSDLPixelFmt(ImgFmt fmt);
    unsigned int getPitch(); 
};

#endif
