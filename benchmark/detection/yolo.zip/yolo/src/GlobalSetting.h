#ifndef GLOBAL_SETTING_H
#define GLOBAL_SETTING_H

const unsigned int CAM_WIDTH = 1280;
const unsigned int CAM_HEIGHT = 720;

enum ImgFmt {
	RGB, YUYV
};

enum PlatformType {
    CPU = 1,
    GPU,
    FPGA
};

struct ARectangle {
	int x;
	int y;
	int width;
	int height;
	int type;
	float prob;
};

#endif
