#include <chrono>
#include "Yolo.h"


extern bool Model1(caffe::NetParameter* param);
extern bool Model2(caffe::NetParameter* param);


// Get all available FPGA devicees
static void get_fpgas(vector<int>* fpgas) 
{
	int count = 0;
#ifndef CPU_ONLY
	//count = caffe::Caffe::EnumerateDevices(false);
#else
	//NO_FPGA;
#endif
	for (int i = 0; i < count; i++) {
		fpgas->push_back(i);
	}
}

Yolo::Yolo(const std::string& modelFile, const std::string& weightFile, PlatformType platform, float pthreshold, float piouThreshold, float piorThreshold, int pnumClass, int pnumBox, int pgrideSize_w, int pgrideSize_h, int skipFrame, bool forceTrack): m_skipFrame(skipFrame)
{
	m_modelFile = modelFile;
	m_weightFile = weightFile;
	m_platform = platform;
	m_threshold = pthreshold;
	m_iouThreshold = piouThreshold;
	m_iorThreshold = piorThreshold;
	m_numClass = pnumClass;
	m_numBox = pnumBox;
	m_grideSize_w = pgrideSize_w;
	m_grideSize_h = pgrideSize_h;
	m_forceTrack = forceTrack;
	m_dataReady = false;
	m_doPrepareData = false;
	m_doShowImg = false;
	m_buffer_size = 0;
	m_frame_count = 0;
	m_fps_show = 0;
	m_ImageShowBuf.clear();	

	// region biases
	//m_region_biases = {1.08,1.19,  3.42,4.41,  6.63,11.38,  9.42,5.11,  16.62,10.52};
	m_region_biases = {0.58154,0.64077,  1.84154,2.37462,  3.56999,6.12769, 5.09983,2.60644, 8.51293,5.38844};

	m_boxes.resize(m_grideSize_w * m_grideSize_h * m_numBox);
	m_boxes_t.resize(m_grideSize_w * m_grideSize_h * m_numBox);
	m_cmp.probs.resize(m_grideSize_w * m_grideSize_h * m_numBox);
	m_cmp_t.probs.resize(m_grideSize_w * m_grideSize_h * m_numBox);
	for(int i=0; i < m_grideSize_w * m_grideSize_h * m_numBox; ++i)
	{
		m_cmp.probs[i].resize(m_numClass);
		m_cmp_t.probs[i].resize(m_numClass);
	}

	printConfig();
	vector<int> fpgas;
	switch (m_platform)
	{
		case CPU:
			caffe::Caffe::set_mode(caffe::Caffe::CPU);
			break;
		case GPU:
			caffe::Caffe::SetDevice(0);
			caffe::Caffe::set_mode(caffe::Caffe::GPU);
			break;
		case FPGA:
			//get_fpgas(&fpgas);
			//caffe::Caffe::SetDevices(fpgas);
			//caffe::Caffe::set_mode(caffe::Caffe::FPGA);
			break;
		default: //cpu
			caffe::Caffe::set_mode(caffe::Caffe::CPU);
			break;
	}

	//caffe::NetParameter param;
	//Model2(&param);
	//m_net.reset(new caffe::Net<float>(param));
	//m_net.reset(new caffe::Net<float>(m_modelFile, caffe::TEST, caffe::Caffe::GetDefaultDevice()));
	m_net.reset(new caffe::Net<float>(m_modelFile, caffe::TEST));
	m_net->CopyTrainedLayersFrom(m_weightFile);
	// CHECK_EQ(m_net->num_inputs(), 1) << "Network should have exactly one input.";
	// CHECK_EQ(m_net->num_outputs(), 1) << "Network should have exactly one output.";
	m_inputBlob = m_net->input_blobs()[0];
	m_imgChannels = m_inputBlob->channels();
	m_imgSize = cv::Size(m_inputBlob->width(), m_inputBlob->height());
}

void Yolo::printConfig()
{
	printf("Yolo config:\n");
	printf("model File path: %s\n", m_modelFile.c_str());
	printf("weight File path: %s\n", m_weightFile.c_str());
	printf("Platform: %s\n", m_platform == CPU ? "CPU" : (m_platform == GPU ? "GPU" : "FPGA"));
	printf("threshold: %f\n", m_threshold);
	printf("iouThreshold: %f\n", m_iouThreshold);
	printf("iorThreshold: %f\n", m_iorThreshold);
	printf("numClass: %d\n", m_numClass);
	printf("numBox: %d\n", m_numBox);
	printf("gridSize: %d\n", m_grideSize_w);
	printf("gridSize: %d\n", m_grideSize_h);
	printf("skipFrame: %d\n", m_skipFrame);
}

void Yolo::predict(cv::Mat& img)
{
	cv::Mat imgResized;
	if(img.size() != m_imgSize){
		cv::resize(img, imgResized, m_imgSize);
	}
	else{
		imgResized = img;
	}
	m_boxes.resize(m_grideSize_w*m_grideSize_h*m_numBox);
	m_cmp.probs.resize(m_grideSize_w*m_grideSize_h*m_numBox);
	for(int i=0; i<m_grideSize_w * m_grideSize_h * m_numBox; ++i)
		m_cmp.probs[i].resize(m_numClass);
	//wrapInputBlob(imgResized);
	wrapInputBlobWithRgb(imgResized);
	//m_result = forward();
	m_result = forwardWithRegion();
	//parse(m_result, m_boxes, m_cmp.probs);
	parseRegion(m_result, m_boxes, m_cmp.probs);
	doSort(m_boxes, m_cmp.probs);
	draw(img, filter(img, m_boxes, m_cmp.probs));
	// return img;
}
void Yolo::predict(cv::Mat& img, std::vector<ARectangle>& boxes)
{
	cv::Mat imgResized;
	if(img.size() != m_imgSize){
		cv::resize(img, imgResized, m_imgSize);
	}
	else{
		imgResized = img;
	}
	m_boxes.resize(m_grideSize_w*m_grideSize_h*m_numBox);
	m_cmp.probs.resize(m_grideSize_w*m_grideSize_h*m_numBox);
	for(int i=0; i<m_grideSize_w * m_grideSize_h * m_numBox; ++i)
		m_cmp.probs[i].resize(m_numClass);
	//wrapInputBlob(imgResized);
	wrapInputBlobWithRgb(imgResized);
	//m_result = forward();
	m_result = forwardWithRegion();
	//parse(m_result, m_boxes, m_cmp.probs);
	parseRegion(m_result, m_boxes, m_cmp.probs);
	doSort(m_boxes, m_cmp.probs);
	
	boxes = filter(img, m_boxes, m_cmp.probs);
	draw(img, boxes);
}

void Yolo::prepareData()
{
	if(m_imgOrg.size() != m_imgSize){
		cv::resize(m_imgOrg, m_imgResized, m_imgSize);
	}
	else{
		m_imgResized = m_imgOrg;
	}
}

void Yolo::netForward()
{
	ShowPacket packet;
	packet.img = m_imgOrg.clone();
	m_doPrepareData = true;
	packet.needParse = true;
	//packet.result = forward();
	packet.result = forwardWithRegion();
	m_result = packet.result; //to be processd in tracker
	packet.rects.clear();
	m_Mutex.Lock();
	m_ImageShowBuf.push_back(packet);
	m_buffer_size++;
	m_frame_count++;
	m_Mutex.UnLock();
}

void Yolo::targetTrack()
{
	//parse(m_result, m_boxes_t, m_cmp_t.probs);
	parseRegion(m_result,m_boxes_t,m_cmp_t.probs);
	doSort(m_boxes_t, m_cmp_t.probs);
	vector<ARectangle> rects = filter(m_imgOrg, m_boxes_t, m_cmp_t.probs);

	int length = rects.size();

	if(length > 0 || m_forceTrack)
	{
		//double start_time = aocl_utils::getCurrentTimestamp();
		ShowPacket packet;
		packet.img = m_imgOrg.clone();
		m_doPrepareData = true;
		packet.needParse = false;
		packet.rects.clear();

		m_trackers.resize(length);
		for(int i=0; i<length; ++i){
//			m_trackers[i] = new KCFTracker(true, false, true, false);
			m_trackers[i] = new KCFTracker(false, true, false, false); //1:HOG  2:Fixed Box  3:Multi-scale  4:LAB
			m_trackers[i]->init(cv::Rect(rects[i].x, rects[i].y, rects[i].width, rects[i].height), packet.img);

			cv::Rect result = m_trackers[i]->update(packet.img);
			ARectangle rect_tmp;
			rect_tmp.x = result.x;
			rect_tmp.y = result.y;
			rect_tmp.width = result.width;
			rect_tmp.height = result.height;
			rect_tmp.type = rects[i].type; 
			rect_tmp.prob = rects[i].prob;
			packet.rects.push_back(rect_tmp);	
		}

		m_Mutex.Lock();
		m_ImageShowBuf.push_back(packet);
		m_buffer_size++;
		m_frame_count++;
		m_Mutex.UnLock();
		//printf("guanxiong: targetTrack()(length > 0) time: %g ms\n", (aocl_utils::getCurrentTimestamp() - start_time) * 1000);
	}
	else
	{
		printf("guanxiong: back to netForward()\n");
		netForward();
	}
}

void Yolo::porcessImageShowData()
{
	if (m_ImageShowBuf.front().needParse)
	{
		//parse(m_ImageShowBuf.front().result, m_boxes, m_cmp.probs);
		parseRegion(m_ImageShowBuf.front().result, m_boxes, m_cmp.probs);

		auto start = std::chrono::system_clock::now();
		doSort(m_boxes, m_cmp.probs);
		std::cout << "guanxiong: doSort time: " << (std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::system_clock::now() - start)).count() / 1000.0 << "ms" << std::endl;

		draw(m_ImageShowBuf.front().img, filter(m_ImageShowBuf.front().img, m_boxes, m_cmp.probs));
	}
	else
	{
		draw(m_ImageShowBuf.front().img, m_ImageShowBuf.front().rects);	
	}
}

vector<float> Yolo::forward()
{
	vector<float> output;
	const float* blobData;

	auto start = std::chrono::system_clock::now();
	m_net->Forward();
	std::cout << "net->Forward: " << std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::system_clock::now() - start).count() << "us" << std::endl;

	boost::shared_ptr<caffe::Blob<float> > outputBlob = m_net->blob_by_name("result");
	int dims = outputBlob->count();
	blobData = outputBlob->cpu_data();
	copy(blobData, blobData+dims, back_inserter(output));

	return output;
}

vector<float> Yolo::forwardWithRegion()
{
	vector<float> output;
	const float* blobData;

	auto start = std::chrono::system_clock::now();
	m_net->Forward();
	std::cout << "net->Forward: " << std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::system_clock::now() - start).count() << "us" << std::endl;

	boost::shared_ptr<caffe::Blob<float> > outputBlob = m_net->blob_by_name("result");
	int dims = outputBlob->count();
	blobData = outputBlob->cpu_data();
	copy(blobData, blobData+dims, back_inserter(output));

	start = std::chrono::system_clock::now();
	// Forward region operator
	region(output);
	std::cout << "region->Forward: " << std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::system_clock::now() - start).count() << "us" << std::endl;

	return output;
}

void Yolo::wrapInputBlob(const cv::Mat& imgResized)
{
	const float scale = 0.0039215686;
	caffe::TransformationParameter param;
	param.set_scale(scale);
	// caffe::DataTransformer<float> dt(param, caffe::TEST, caffe::Caffe::GetDevice(0, true));
	//caffe::DataTransformer<float> dt(param, caffe::TEST, caffe::Caffe::GetDefaultDevice());
	caffe::DataTransformer<float> dt(param, caffe::TEST);
	dt.Transform(imgResized, m_inputBlob);
}

void Yolo::wrapInputBlobWithRgb(const cv::Mat& imgResized)
{
	auto start = std::chrono::system_clock::now();
	cv::Mat img_cvt;
	cv::cvtColor(imgResized, img_cvt, cv::COLOR_BGR2RGB);
	std::cout << "convert BGR to RGB: " << std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::system_clock::now() - start).count() << "us" << std::endl;

	const float scale = 0.0039215686;
	caffe::TransformationParameter param;
	param.set_scale(scale);
	// caffe::DataTransformer<float> dt(param, caffe::TEST, caffe::Caffe::GetDevice(0, true));
	//caffe::DataTransformer<float> dt(param, caffe::TEST, caffe::Caffe::GetDefaultDevice());
	caffe::DataTransformer<float> dt(param, caffe::TEST);
	dt.Transform(img_cvt, m_inputBlob);
}

void Yolo::parse(const vector<float>& result, vector<Box>& boxes, vector<vector<float> >& probs)
{
	// m_grideSize * m_grideSize * m_numClass + m_grideSize * m_grideSize * confidence + m_grideSize * m_grideSize * (m_numBox * 4)
	// default   7*7*20 + 7*7*1 + 7*7*2*4
	// 4 means (x, y, width, height)
	for(int i=0; i<m_grideSize_w*m_grideSize_h; ++i){
		int row = i / m_grideSize_w;
		int col = i % m_grideSize_w;
		for(int j=0; j<m_numBox; ++j){
			int index = i*m_numBox + j;
			int pIndex = m_grideSize_w * m_grideSize_h * m_numClass + index;
			int boxIndex = m_grideSize_w * m_grideSize_h * (m_numClass + m_numBox) + (index << 2);
			float scale = result[pIndex];
			boxes[index].x = (result[boxIndex + 0] + col) / m_grideSize_w;
			boxes[index].y = (result[boxIndex + 1] + row) / m_grideSize_h;
			boxes[index].w = pow(result[boxIndex + 2], 2);
			boxes[index].h = pow(result[boxIndex + 3], 2);

			for(int k=0; k<m_numClass; ++k){
				int classIndex = i*m_numClass;
				float prob = scale*result[classIndex+k];
				probs[index][k] = (prob > m_threshold) ? prob : 0;
			}
		}
	}
}

void Yolo::parseRegion(const vector<float>& result, vector<Box>& boxes, vector<vector<float> >& probs)
{
    auto start = std::chrono::system_clock::now();
    // One Box Block with (4 + 1 + num_class) channels
    // note: 4 means (x, y, width, height), 1 means Pobj
    for(int i=0; i<m_grideSize_w*m_grideSize_h; ++i){
	int row = i / m_grideSize_w;
	int col = i % m_grideSize_w;
	for(int n=0; n<m_numBox; ++n){
	    int index = n*m_grideSize_w*m_grideSize_h + i;
	    int box_index = entryIndex(index, 0);
	    int obj_index = entryIndex(index, 4);
	    float scale = result[obj_index];
	    int stride = m_grideSize_w*m_grideSize_h;
	    boxes[index].x = (col + result[box_index + 0*stride]) / m_grideSize_w;
	    boxes[index].y = (row + result[box_index + 1*stride]) / m_grideSize_h;
	    boxes[index].w = exp(result[box_index + 2*stride]) * m_region_biases[2*n] / m_grideSize_w;
	    boxes[index].h = exp(result[box_index + 3*stride]) * m_region_biases[2*n+1] / m_grideSize_h;
	    
	    for(int k=0; k<m_numClass; ++k){
		int class_index = entryIndex(index, 5+k);
		float prob = scale * result[class_index];
		probs[index][k] = (prob > m_threshold) ? prob : 0;
	    }
	}
    }
    std::cout << "parse region: " << std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::system_clock::now() - start).count() << "us" << std::endl;
}

void Yolo::doSort(vector<Box>& boxes, vector<vector<float> >& probs)
{
	int total = m_grideSize_w * m_grideSize_h * m_numBox;

	for(int i=0; i<total; ++i){
		int any_t=0;
		for(int j=0; j<m_numClass; ++j){
			any_t = any_t || probs[i][j] > 0;
		}
		if(!any_t) continue;

		Box &a = boxes[i];
		for(int j=i+1; j<total; ++j)
		{
			Box &b = boxes[j];
			if(boxIou(a,b) > m_iouThreshold){
			    printf("filter IoU\n");
				for(int k=0; k<m_numClass; ++k)
				{
					if(probs[i][k] < probs[j][k])
						probs[i][k] = 0.0;
					else
						probs[j][k] = 0.0;
				}
			}else if(boxIor(a,b) > m_iorThreshold){
			    printf("filter IoR\n");
				for(int k=0; k<m_numClass; ++k)
				{
					if(probs[i][k] < probs[j][k])
						probs[i][k] = 0.0;
					else
						probs[j][k] = 0.0;
				}
			}
		}
	}
}

vector<ARectangle> Yolo::filter(cv::Mat& img, vector<Box>& boxes, vector<vector<float> >& probs)
{
	vector<ARectangle> rects;
	rects.clear();
	int num = m_grideSize_w * m_grideSize_h * m_numBox;
	int wImg = img.cols;
	int hImg = img.rows;
	for(int i = 0; i < num; ++i){
		int kind = maxIndex(probs[i], m_numClass);
		float prob = probs[i][kind];
		if(prob > m_threshold){
			const Box& b = boxes[i];

			int left  = (b.x-b.w/2.)*wImg;
			int right = (b.x+b.w/2.)*wImg;
			int top   = (b.y-b.h/2.)*hImg;
			int bot   = (b.y+b.h/2.)*hImg;

			if(left < 0) left = 0;
			if(right > wImg-1) right = wImg-1;
			if(top < 0) top = 0;
			if(bot > hImg-1) bot = hImg-1;

			ARectangle rt;
			rt.x = left;
			rt.y = top;
			rt.width = right - left;
			rt.height = bot - top;
			rt.type = kind;
			rt.prob = prob;
			rects.push_back(rt);
		}
	}
	return rects;
}

void Yolo::draw(cv::Mat& img, vector<ARectangle> rects)
{
	//static const string names[] = {"truck", "car", "person"};
	static const string names[] = {"Car", "Pedestrian", "Cyclist"};
	for(unsigned int i = 0; i < rects.size(); ++i){
		int kind = rects[i].type;
		int w = rects[i].width;
		int h = rects[i].height;
		int x = rects[i].x + (w >> 1); 
		int y = rects[i].y + (h >> 1);
		cout << "x y w h " << x << "\t" << y << "\t" << w << "\t" << h << std::endl;
		cv::Point leftTop = cv::Point(rects[i].x, rects[i].y);
		cv::Point rightBottom = cv::Point(rects[i].x + rects[i].width, rects[i].y + rects[i].height);
		if(2 == kind) {
			cv::rectangle(img, leftTop, rightBottom, cv::Scalar(0, 255 ,0), 2);
			putText(img, names[kind].c_str(), cv::Point(leftTop.x, leftTop.y - 5), CV_FONT_HERSHEY_COMPLEX, 0.5, cv::Scalar(0, 255, 0));
		}
		else if (1 == kind) {
			cv::rectangle(img, leftTop, rightBottom, cv::Scalar(0, 0 ,255), 2);
			putText(img, names[kind].c_str(), cv::Point(leftTop.x, leftTop.y - 5), CV_FONT_HERSHEY_COMPLEX, 0.5, cv::Scalar(0, 0, 255));
		}
		else if (0 == kind) {
			cv::rectangle(img, leftTop, rightBottom, cv::Scalar(255, 0 ,0), 2);
			putText(img, names[kind].c_str(), cv::Point(leftTop.x, leftTop.y - 5), CV_FONT_HERSHEY_COMPLEX, 0.5, cv::Scalar(255, 0, 0));
		}
		cout << names[kind] << ":\t" << rects[i].prob << endl;
	}
}

// intersection-over-region
float Yolo::boxIor(const Box& a, const Box& b)
{
    float iora = boxIntersection(a, b) / (a.w * a.h);
    float iorb = boxIntersection(a, b) / (b.w * b.h);
    return (iora > iorb) ? iora : iorb;
}

float Yolo::boxIou(const Box& a, const Box& b)
{
	return boxIntersection(a, b) / boxUnion(a,b);
}

float Yolo::boxIntersection(const Box& a, const Box& b)
{
	float w = overlap(a.x, a.w, b.x, b.w);
	float h = overlap(a.y, a.h, b.y, b.h);
	if(w<0 || h<0) return 0;
	return w*h;
}

float Yolo::boxUnion(const Box& a, const Box& b)
{
	return a.w * a.h + b.w * b.h - boxIntersection(a, b);
}

float Yolo::overlap(float x1, float w1, float x2, float w2)
{
	float l1 = x1 - w1/2;
	float l2 = x2 - w2/2;
	float left = l1 > l2 ? l1 : l2;
	float r1 = x1 + w1/2;
	float r2 = x2 + w2/2;
	float right = r1 < r2 ? r1 : r2;
	return right - left;
}

int Yolo::maxIndex(const vector<float>& a, int n)
{
	if(n<=0) return -1;
	int i, max_i = 0;
	float maxn = a[0];
	for(i = 1; i < n; ++i){
		// cout<<"a "<<i<<"\t"<<a[i]<<endl;
		if(a[i] > maxn){
			maxn = a[i];
			max_i = i;
		}
	}
	return max_i;
}

void Yolo::region(vector<float>& result)
{
	// Logistic activation for x,y and Pobj
	for(int n=0; n<m_numBox; ++n){
	    int idx = entryIndex(n*m_grideSize_w*m_grideSize_h, 0);
	    logisticArray(result, idx, 2*m_grideSize_w*m_grideSize_h);
	    idx = entryIndex(n*m_grideSize_w*m_grideSize_h, 4);
	    logisticArray(result, idx, m_grideSize_w*m_grideSize_h);
	}
	// Softmax activation for classes
	int idx = entryIndex(0, 5);
	softmaxArray(result, idx, m_numClass, m_numBox, result.size()/m_numBox, m_grideSize_w*m_grideSize_h, 1, m_grideSize_w*m_grideSize_h, 1);
}

int Yolo::entryIndex(int location, int entry)
{
	int n = location / (m_grideSize_w*m_grideSize_h);
	int loc = location % (m_grideSize_w*m_grideSize_h);
	return n * (m_grideSize_w*m_grideSize_h) * (4+1+m_numClass) + entry * (m_grideSize_w*m_grideSize_h) +loc;
}

void Yolo::logisticArray(vector<float>& result, int idx_start, const int n)
{
	for(int i=0; i<n; ++i){
	    result[idx_start+i] = 1. / ( 1. + exp(-result[idx_start+i]) );
	}
}

void Yolo::softmaxArray(vector<float>& result, int idx_start, int num_class, int num_box, int box_offset, int location, int loc_offset, int stride, float temp)
{
    for(int n=0; n<num_box; ++n){
	for(int loc=0; loc<location; ++loc){
	    softmaxOperator(result, idx_start+n*box_offset+loc*loc_offset, num_class, stride, temp);
	}
    }
}

void Yolo::softmaxOperator(vector<float>& result, int idx_start, int num_class, int stride, float temp)
{
    float sum = 0;
    float largest = -FLT_MAX;

    for(int i=0; i<num_class; ++i){
	if(result[idx_start+i*stride] > largest) largest = result[idx_start+i*stride];
    }
    for(int i=0; i<num_class; ++i){
	float e = exp(result[idx_start+i*stride]/temp - largest/temp);
	sum += e;
	result[idx_start+i*stride] = e;
    }
    for(int i=0; i<num_class; ++i){
	result[idx_start+i*stride] /= sum;
    }
}
