/**
 *Auther: Dai, Guanxiong <daigx_1124@163.com>
 *Copyright (c) 2016 Intel Corporation. All rights reserved.
 */

#ifndef COMMON_CKEYDETECT_H
#define COMMON_CKEYDETECT_H

#include <termios.h>

bool kbHit(int c);

class CKeyDetect {
public:
	CKeyDetect();
	~CKeyDetect();

	bool kbHit(int c);

private:
	struct termios old_term_attr;
	struct termios new_term_attr;
	int old_file_status;

	void initKeyboard();
	void closeKeyboard();
};

#endif
