/**
 *Auther: Lv, Yueqiang <yueqiang.lu@intel.com>
 *Copyright (c) 2016 Intel Corporation. All rights reserved.
 */

#ifndef CEXEPTION_H
#define CEXEPTION_H

#include <iostream>
#include <string>

using namespace std;

class CException
{
public:
	virtual ~CException();
	CException(string sError);
	CException(char *pError);
	char * GetError(void );
	virtual void ProcessExtion();

protected:
	string m_strError;
};

#endif
