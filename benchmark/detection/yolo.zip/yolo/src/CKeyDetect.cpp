/**
 *Auther: Dai, Guanxiong <daigx_1124@163.com>
 *Copyright (c) 2016 Intel Corporation. All rights reserved.
 */

#include <term.h>  
#include <unistd.h>  
#include <stdio.h>
#include <stdlib.h>  
#include <fcntl.h>  
#include "CKeyDetect.h"


bool kbHit(int c) {
	struct termios old_term_attr;
	struct termios new_term_attr;
	int old_file_status;
	int ch;

	tcgetattr(STDIN_FILENO, &old_term_attr);  
	new_term_attr = old_term_attr;  
	new_term_attr.c_lflag &= ~(ICANON | ECHO);  
	tcsetattr(STDIN_FILENO, TCSANOW, &new_term_attr);  
	old_file_status = fcntl(STDIN_FILENO, F_GETFL, 0);  
	fcntl(STDIN_FILENO, F_SETFL, old_file_status | O_NONBLOCK);  

	ch = getchar();

	tcsetattr(STDIN_FILENO, TCSANOW, &old_term_attr);  
	fcntl(STDIN_FILENO, F_SETFL, old_file_status);  

	return ch == c;
}


CKeyDetect::CKeyDetect() { initKeyboard(); }
CKeyDetect::~CKeyDetect() { closeKeyboard(); }

void CKeyDetect::initKeyboard()  
{  
	tcgetattr(STDIN_FILENO, &old_term_attr);  
	new_term_attr = old_term_attr;  
	new_term_attr.c_lflag &= ~(ICANON | ECHO);  
	tcsetattr(STDIN_FILENO, TCSANOW, &new_term_attr);  

	old_file_status = fcntl(STDIN_FILENO, F_GETFL, 0);  
	fcntl(STDIN_FILENO, F_SETFL, old_file_status | O_NONBLOCK);  
}  

void CKeyDetect::closeKeyboard()  
{  
	tcsetattr(STDIN_FILENO, TCSANOW, &old_term_attr);  
	fcntl(STDIN_FILENO, F_SETFL, old_file_status);  
} 

bool CKeyDetect::kbHit(int c) { return getchar() == c; }  
