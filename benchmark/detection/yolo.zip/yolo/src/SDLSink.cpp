#include "SDLSink.h"
#include "log.h"

SDLSink::SDLSink(){
	this->width = CAM_WIDTH;
	this->height = CAM_HEIGHT;
	this->rect.x = 0;
	this->rect.y = 0;
	this->rect.w = CAM_WIDTH;
	this->rect.h = CAM_HEIGHT;
	//this->pixels = malloc(CAM_WIDTH*CAM_HEIGHT*2);//FIXME:hardcode YUYV formate
}

SDLSink::SDLSink(int x, int y, unsigned int w, unsigned int h){
	this->px = x;
	this->py = y;
	this->width = w;
	this->height = h;
	this->rect.x = 0;
	this->rect.y = 0;
	this->rect.w = w;
	this->rect.h = h;
}

SDLSink::~SDLSink(){
	//free(this->pixels);
	closeSink();
}

bool SDLSink::openSink(){
	/* initializing SDL */
	if(SDL_Init(SDL_INIT_VIDEO)) {
		LOG_E("Could not initialize SDL - %s\n", SDL_GetError());
		return false;
	}

	this->surface = SDL_CreateWindow("GR ADAS POC",
			this->px,
			this->py,
			this->width, this->height,
			/*SDL_WINDOW_FULLSCREEN_DESKTOP|*/SDL_WINDOW_RESIZABLE);
	if(this->surface == NULL){
		LOG_E("failed to set up screen\n");
		SDL_Quit();
		return false;
	}
	this->renderer = SDL_CreateRenderer(this->surface, -1, 0);
	if(this->renderer == NULL)
	{
		LOG_E("failed to create renderer\n");
		SDL_DestroyWindow(this->surface);
		SDL_Quit();
		return false;
	}
	SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "linear");  // make the scaled rendering look smoother.
	SDL_RenderSetLogicalSize(this->renderer, this->width,this->height);
	LOG_I("Open SDL Sink successfully!");
	return true;
}

void SDLSink::closeSink(){
	if(this->surface)
		SDL_Quit();
}

bool SDLSink::lockData(){
	return true;
}

bool SDLSink::unlockData(){
	return true;
}

void* SDLSink::getData(){
	return this->pixels;
}

void SDLSink::render(){
	SDL_RenderClear(this->renderer);
	SDL_RenderCopy(this->renderer,this->texture, NULL, &this->rect);
	SDL_RenderPresent(this->renderer);
}

void SDLSink::render(void* p){
	LOG_D("In SDLSink::render function");
	SDL_UpdateTexture(this->texture, NULL, p, getPitch());
	SDL_RenderClear(this->renderer);
	SDL_RenderCopy(this->renderer,this->texture, NULL, &this->rect);
	SDL_RenderPresent(this->renderer);
}

unsigned int SDLSink::getPitch(){
	switch(this->texture_f){
		case YUYV:
			LOG_D("get pitch: %d",texture_w*2);
			return this->texture_w*2;
		case RGB:
			LOG_D("get pitch: %d",texture_w*3);
			return this->texture_w*3;
		default:
			return this->texture_w*2;
	}
}

void SDLSink::updateVideoBuffer(void* buffer){
	LOG_D("in SDLSink::updateVideoBuffer function");
	this->pixels = buffer;
	SDL_UpdateTexture(this->texture, NULL, buffer, getPitch());
}

bool SDLSink::drawObject(const DRAW_OBJECT object, void* data){
	switch(object){
		case draw_rect:
			{
				ARectangle* r = (ARectangle*) data;
				LOG_D("#### %d %d %d %d ####",r->x, r->y, r->width, r->height);
				drawRect(r);
				break;
			}
		case draw_pixel:
			break;
		case draw_line:
			break;
		case draw_circle:
			break;
	}
	return true;
}

void SDLSink::drawLine(int x, int y, int len){
	/*
	   int w = this->width * 2;
	   memset((unsigned char*)this->pixels+y*w + x*2, 255, len*2);
	 */
}

void SDLSink::drawRect(ARectangle* r){
	/*
	   int i = 0;
	   drawLine(r->x,r->y,r->width);
	   for(;i<r->height;i++)
	   drawLine(r->x,r->y+i,1);
	   for(i=0;i<r->height;i++)
	   drawLine(r->x+r->width,r->y+i,1);
	   drawLine(r->x,r->y+r->height,r->width);
	 */
	switch(r->type){
		// people
		case 14:
			SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);
			break;
			// car
		case 6:
			SDL_SetRenderDrawColor(renderer, 0, 255, 0, 255);
			break;
			// others
		default:
			SDL_SetRenderDrawColor(renderer, 0, 0, 255, 255);
			break;
	}
	SDL_Rect rect = {r->x,r->y,r->width,r->height};
	SDL_RenderDrawRect(this->renderer, &rect);
	SDL_RenderPresent(this->renderer);
}

bool SDLSink::setTexture(unsigned int w, unsigned int h, ImgFmt fmt){
	LOG_D("Set Texture w:%d h:%d",w,h);
	this->texture_w = w;
	this->texture_h = h;
	this->texture_f = fmt;
	this->texture = SDL_CreateTexture(this->renderer, getSDLPixelFmt(fmt), SDL_TEXTUREACCESS_STREAMING, w, h);
	if(this->texture==NULL){
		LOG_E("failed to create texture\n");
		SDL_DestroyRenderer(this->renderer);
		SDL_DestroyWindow(this->surface);
		SDL_Quit();
		return false;
	}
	return true;
}

int SDLSink::getSDLPixelFmt(ImgFmt fmt){
	switch(fmt){
		case YUYV: 
			return SDL_PIXELFORMAT_YUY2;
		case RGB:
			return SDL_PIXELFORMAT_BGR24;
		default:
			return SDL_PIXELFORMAT_YUY2;
	}
}
